const knexfile = require("../knexfile");
const knex = require("knex");

const con = knex(knexfile);

module.exports = con;
