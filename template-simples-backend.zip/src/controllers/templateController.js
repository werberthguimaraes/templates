const knex = require("../db/database");

//index, show, create, update, delete
async function index(req, res) {
  return res.json({ ok: "ok" });
}

//retorna 1 objeto
async function show(req, res) {
  return res.json({ ok: "ok" });
}

// insere objeto no banco e retorna o id
async function create(req, res) {
  return res.json({ ok: "ok" });
}

// atualiza objeto no banco e retorna o objeto
async function update(req, res) {
  return res.json({ ok: "ok" });
}

// atualiza objeto no banco e retorna o objeto
async function remove(req, res) {
  return res.json({ ok: "ok" });
}

module.exports = {
  index,
  show,
  create,
  update,
  remove,
};
