const dir = "/gestor";

module.exports = dir;
