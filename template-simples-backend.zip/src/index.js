const express = require("express");
const path = require("path");
const cors = require("cors");

const dir = require("./config/caminho");

const templateRouter = require("./routes/templateRouter");

const app = express();

app.use(express.json());
app.use(cors());

//rota para acessar quivos staticos
app.use(express.static(path.resolve(__dirname, "..", "uploads")));

app.use(dir + "/", templateRouter);

app.listen(3333, function () {
  console.log(3333);
  console.log("Rodando o server! contexto" + dir);
});
