// Update with your config settings.
const env = require("./.env");
const path = require("path");

module.exports = {
  client: "mysql",
  connection: {
    host: env.host_db,
    database: env.database,
    user: env.user,
    password: env.password,
  },
  pool: {
    min: 2,
    max: 10,
  },
  migrations: {
    directory: path.resolve(__dirname, "migrations"),
    // tableName: "knex_migrations",
  },
  seeds: {
    directory: path.resolve(__dirname, "seeds"),
  },
};
