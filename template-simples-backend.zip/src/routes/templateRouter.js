const express = require("express");
const templateController = require("../controllers/templateController");
const routes = express.Router();

routes.get("/", templateController.index);

routes.get("/:id", templateController.show);

routes.post("/", templateController.create);

routes.put("/", templateController.update);

routes.delete("/:id", templateController.remove);

module.exports = routes;
